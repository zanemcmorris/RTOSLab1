#ifndef INTERRUPTCONTROL_H_
#define INTERRUPTCONTROL_H_

//#include "stm32f429xx.h"
#include "stm32f4xx_hal.h"

#define _vo volatile

/* Set Enable */
#define NVIC_ISER0					((_vo uint32_t*) 0xE000E100)
#define NVIC_ISER1					((_vo uint32_t*) 0xE000E104)
#define NVIC_ISER2					((_vo uint32_t*) 0xE000E108)

/* Clear Enable */
#define NVIC_ICER0					((_vo uint32_t*) 0XE000E180)
#define NVIC_ICER1					((_vo uint32_t*) 0XE000E184)
#define NVIC_ICER2					((_vo uint32_t*) 0XE000E188)

/* Set Pending */
#define NVIC_ISPR0					((_vo uint32_t*) 0XE000E200)
#define NVIC_ISPR1					((_vo uint32_t*) 0XE000E204)
#define NVIC_ISPR2					((_vo uint32_t*) 0XE000E208)

/* Clear Pending */
#define NVIC_ICPR0					((_vo uint32_t*) 0XE000E280)
#define NVIC_ICPR1					((_vo uint32_t*) 0XE000E284)
#define NVIC_ICPR2					((_vo uint32_t*) 0XE000E288)

/*  Active Bit */
#define NVIC_IABR0					((_vo uint32_t*) 0xE000E300)
#define NVIC_IABR1					((_vo uint32_t*) 0xE000E304)
#define NVIC_IABR2					((_vo uint32_t*) 0xE000E308)

/*  Interrupt Priority */
#define NVIC_IPR0					((_vo uint32_t*) 0xE000E400)
#define NVIC_IPR1					((_vo uint32_t*) 0xE000E404)
#define NVIC_IPR2					((_vo uint32_t*) 0xE000E408)



// IRQ Numbers
#define EXTI0_IRQ_NUMBER            6

void EnableInterrupt(uint8_t irqNumber);
void DisableInterrupt(uint8_t irqNumber);
//void ConfigureInterruptPriority(uint8_t irqNumber, uint8_t irqPriority);
void ClearPendingInterrupt(uint8_t irqNumber);
void SetPendingIntterupt(uint8_t irqNumber); // Mianly will be used for testing
void EXTI_ClearPendingRegister(uint8_t pinNumber);

#endif
