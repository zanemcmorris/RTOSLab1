#ifndef GYRO_H_
#define GYRO_H_

#include "stm32f429xx.h"
#include "stm32f4xx_hal.h"
#include "stm32f4xx_hal_conf.h"
#include "stm32f4xx_it.h"

#include <stdbool.h>
#include <stdio.h>
#include "ErrorHandling.h"

#define I3G4250D_SENSITIVITY 	I3G4250D_SENSITIVITY_500DPS		//sens
#define I3G4250D_SCALE_SELECTION		I3G4250D_FULLSCALE_500
//#define I3G4250D_SENSITIVITY 	I3G4250D_SENSITIVITY_2000DPS		//sens
//#define I3G4250D_SCALE_SELECTION	I3G4250D_FULLSCALE_2000

#define I3G4250D_FULLSCALE_245       ((uint8_t)0x00)
#define I3G4250D_FULLSCALE_500       ((uint8_t)0x10)
#define I3G4250D_FULLSCALE_2000      ((uint8_t)0x20)
#define I3G4250D_FULLSCALE_SELECTION ((uint8_t)0x30)
#define I3G4250D_SENSITIVITY_245DPS  ((float)8.75f)         /*gyroscope sensitivity 250 dps */
#define I3G4250D_SENSITIVITY_500DPS  ((float)17.50f)        /*gyroscope sensitivity 500 dps */
#define I3G4250D_SENSITIVITY_2000DPS ((float)70.00f)        /*gyroscope sensitivity 2000 dps*/

/******************************************************************************/
/*************************** START REGISTER MAPPING  **************************/
/******************************************************************************/
#define I3G4250D_WHO_AM_I_ADDR          0x0F  /* device identification register */
#define I3G4250D_CTRL_REG1_ADDR         0x20  /* Control register 1 */
#define I3G4250D_CTRL_REG2_ADDR         0x21  /* Control register 2 */
#define I3G4250D_CTRL_REG3_ADDR         0x22  /* Control register 3 */
#define I3G4250D_CTRL_REG4_ADDR         0x23  /* Control register 4 */
#define I3G4250D_CTRL_REG5_ADDR         0x24  /* Control register 5 */
#define I3G4250D_REFERENCE_REG_ADDR     0x25  /* Reference register */
#define I3G4250D_OUT_TEMP_ADDR          0x26  /* Out temp register */
#define I3G4250D_STATUS_REG_ADDR        0x27  /* Status register */
#define I3G4250D_OUT_X_L_ADDR           0x28  /* Output Register X */
#define I3G4250D_OUT_X_H_ADDR           0x29  /* Output Register X */
#define I3G4250D_OUT_Y_L_ADDR           0x2A  /* Output Register Y */
#define I3G4250D_OUT_Y_H_ADDR           0x2B  /* Output Register Y */
#define I3G4250D_OUT_Z_L_ADDR           0x2C  /* Output Register Z */
#define I3G4250D_OUT_Z_H_ADDR           0x2D  /* Output Register Z */
#define I3G4250D_FIFO_CTRL_REG_ADDR     0x2E  /* Fifo control Register */
#define I3G4250D_FIFO_SRC_REG_ADDR      0x2F  /* Fifo src Register */

#define I3G4250D_INT1_CFG_ADDR          0x30  /* Interrupt 1 configuration Register */
#define I3G4250D_INT1_SRC_ADDR          0x31  /* Interrupt 1 source Register */
#define I3G4250D_INT1_TSH_XH_ADDR       0x32  /* Interrupt 1 Threshold X register */
#define I3G4250D_INT1_TSH_XL_ADDR       0x33  /* Interrupt 1 Threshold X register */
#define I3G4250D_INT1_TSH_YH_ADDR       0x34  /* Interrupt 1 Threshold Y register */
#define I3G4250D_INT1_TSH_YL_ADDR       0x35  /* Interrupt 1 Threshold Y register */
#define I3G4250D_INT1_TSH_ZH_ADDR       0x36  /* Interrupt 1 Threshold Z register */
#define I3G4250D_INT1_TSH_ZL_ADDR       0x37  /* Interrupt 1 Threshold Z register */
#define I3G4250D_INT1_DURATION_ADDR     0x38  /* Interrupt 1 DURATION register */

/******************************************************************************/
/**************************** END REGISTER MAPPING  ***************************/
/******************************************************************************/

#define I3G4250D_WRITE 					(0<<7)
#define I3G4250D_READ 					(1<<7)
#define I3G4250D_MS_BIT					(1<<6)	/* MS bit, increments the address for continus reads, and writes.*/

#define GYRO_SCK_PIN                    GPIO_PIN_7
#define GYRO_SCK_PORT                   GPIOF
#define GYRO_MISO_Pin                   GPIO_PIN_8
#define GYRO_MISO_PORT                  GPIOF
#define GYRO_MOSI_Pin                   GPIO_PIN_9
#define GYRO_MOSI_PORT                  GPIOF
#define GYRO_CS_Pin                     GPIO_PIN_1  // Active Low
#define GYRO_CS_PORT                    GPIOC       // Active Low

#define TESTING_TIMEOUT					20000

void Gyro_Init(void);
void Gyro_PrintWhoAmI(void); // Students may be allowed to use printf statements
void Gyro_PowerOnDevice(void);

void Gyro_RebootCmd(void);
void Gyro_Write_Reg(uint8_t regtoWrite, uint8_t data);
uint8_t Gyro_Read_Reg(uint8_t regToRead);
void VerifyGyroHALStatusIsOkay(void);

void Gyro_ReadXYZAngRate(void);
void Gyro_ReadTemperature(void);
void Gyro_Process_Gyro_Data(float *d);
uint8_t Gyro_Get_Rotation_Rate_Direction(void);

void Gyro_EnableSlaveCommunicationManually(void);
void Gyro_DisableSlaveCommunicationManually(void);

void Gyro_Configure_Regs(void);
void Gyro_RebootDevice(void);

// Helper functions for returning Gyro values

typedef enum{
	GYRO_NEUTRAL = 0,
	GYRO_LEFT = 1,
	GYRO_RIGHT = 2
}GYRO_DIRECTION;

typedef enum{
	GYRO_RATE_FAST_CCW = 0,
	GYRO_RATE_SLOW_CCW = 1,
	GYRO_RATE_NEUTRAL = 2,
	GYRO_RATE_SLOW_CW = 3,
	GYRO_RATE_FAST_CW = 4
}GYRO_RATE_DIRECTION;

typedef enum{
	GYRO_X_DATA = 0,
	GYRO_Y_DATA = 1,
	GYRO_Z_DATA = 2
}GYRO_RAW_DATA;


#endif 
