/*
 * ErrorHandling.h
 *
 *  Created on: Apr 22, 2023
 *      Author: Xavion
 */

#ifndef ERRORHANDLING_H_
#define ERRORHANDLING_H_

#include <stdbool.h>

// This does not return. 
void APPLICATION_ASSERT(bool condition);


#endif /* ERRORHANDLING_H_ */
