/*
 * Application_Code.h
 *
 *  Created on: Jan 12, 2024
 *      Author: Zane
 */

#ifndef INC_APPLICATION_CODE_H_
#define INC_APPLICATION_CODE_H_

//#include "stm32f4xx_hal_conf.h"
#include "stm32f4xx_hal.h"
#include "stdbool.h"
#include "Gyro.h"
#include "InterruptControl.h"

#define LAB2_USE_INTERUPT (1)

#define GREEN_LED_PORT GPIOG
#define RED_LED_PORT GPIOG

#define GREEN_LED_PIN GPIO_PIN_13
#define RED_LED_PIN GPIO_PIN_14

#define USER_BTN_PORT GPIOA
#define USER_BTN_PIN GPIO_PIN_0

// Needed setup call to enable interrupts and stuff
void setupApplication();
// Helper functions to drive LEDs simply
void toggleGreenLED();
void toggleRedLED();
void driveRedLEDFromUserButton();
void driveLEDSFromGyro(uint8_t);

#endif /* INC_APPLICATION_CODE_H_ */
