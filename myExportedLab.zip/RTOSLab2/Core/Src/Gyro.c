/*
 * spi.h
 *
 *  Created on: Jun 5, 2023
 *      Author: Xavion, mathias
 */

#include "Gyro.h"

SPI_HandleTypeDef hspi5;
HAL_StatusTypeDef gyroHALStatus = HAL_OK;
static uint16_t DeviceID;

void Gyro_Init(void) {
	GPIO_InitTypeDef SpiPinConfiguration = { 0 };
	// GPIO configurations are taken care of in the HAL_SPI_Init() function, they are initialzieds in a MSP Init
	// Which knows that we are using as specific microcontroller and knows that SPI5 is for the Gyro.. We are just doing it here for completeness
	/**SPI5 GPIO Configuration
	 PF7     ------> SPI5_SCK
	 PF8     ------> SPI5_MISO
	 PF9     ------> SPI5_MOSI
	 PC1     ------> SPI5_CS
	 */

	__HAL_RCC_GPIOC_CLK_ENABLE();//Add clock enables. The GPIOF clock was being enabled, but not the GPIOC clock, so add these to explictly enable.
	__HAL_RCC_GPIOF_CLK_ENABLE();

	SpiPinConfiguration.Pin = GYRO_MISO_Pin | GYRO_SCK_PIN | GYRO_MOSI_Pin;
	SpiPinConfiguration.Mode = GPIO_MODE_AF_PP;
	SpiPinConfiguration.Pull = GPIO_NOPULL;
	SpiPinConfiguration.Speed = GPIO_SPEED_FREQ_LOW;
	SpiPinConfiguration.Alternate = GPIO_AF5_SPI5;
	HAL_GPIO_Init(GYRO_MISO_PORT, &SpiPinConfiguration);

	/* Chip Select */
	SpiPinConfiguration.Pin = GYRO_CS_Pin;
	SpiPinConfiguration.Mode = GPIO_MODE_OUTPUT_OD;	// CS "should" be open drain is what some websites said so it cant break anything and like "over drive" the pin but i dont think it really matters if its like PP or OD.
	SpiPinConfiguration.Pull = GPIO_PULLUP;				// CS made pullup.
	SpiPinConfiguration.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GYRO_CS_PORT, &SpiPinConfiguration);
	HAL_GPIO_WritePin(GYRO_CS_PORT, GYRO_CS_Pin, GPIO_PIN_SET); //Set it; defaults to 0, pull low.

	// Enabling of the clock for SPI5 happens within the Init function
	/* SPI5 parameter configuration*/
	hspi5.Instance = SPI5;
	hspi5.Init.Mode = SPI_MODE_MASTER;
	hspi5.Init.Direction = SPI_DIRECTION_2LINES;
	hspi5.Init.DataSize = SPI_DATASIZE_8BIT; // We can use 8 or 16 bit, but the device is 8 bit. The registers and stuff are only 8 bits, so we should use 8 bit. If the gyro sent us two bytes or we sent it two bytes to access the reg it would be 16 bit. You can use 16 bit as a way of having it send out the dummy data for the remaining 8 bits to keep the clokc going and get data from the sensor. The hal does not do this. So we use 8 bit.
	hspi5.Init.CLKPolarity = SPI_POLARITY_HIGH; // The data sheet shows a high clock polariy. It is a 1 before the communaction starts so we want to have it high here. Im pretty sure the polairty doesnt matter for this sensor, but I dont know. For most spi devices they dont care so much about the polarity.
	hspi5.Init.CLKPhase = SPI_PHASE_2EDGE;
	hspi5.Init.NSS = SPI_NSS_SOFT;
	hspi5.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_64; // The clock that is going to this branch is running mega fast.
	hspi5.Init.FirstBit = SPI_FIRSTBIT_MSB;
	hspi5.Init.TIMode = SPI_TIMODE_DISABLE;			//No change here, but using
	hspi5.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	hspi5.Init.CRCPolynomial = 0; //This doesnt matter if the CRC is set to SPI_CRCCALCULATION_DISABLE.
	if (HAL_SPI_Init(&hspi5) != HAL_OK) {
		APPLICATION_ASSERT(false);
	}

}

// Note the below two functions are used when the NSS pin cannot be configured.
// The NSS pin automatically acts as a chip select... however, sometimes we may not want that or cannot use that functionality
void Gyro_EnableSlaveCommunicationManually() {
	// Pull GPIO low to manually to act as chip select
	// Chip Select - PC1
	HAL_GPIO_WritePin(GYRO_CS_PORT, GYRO_CS_Pin, GPIO_PIN_RESET);
}

void Gyro_DisableSlaveCommunicationManually() {
	// Pull GPIO high to manually act as releasing chip select
	// Chip Select - PC1
	HAL_GPIO_WritePin(GYRO_CS_PORT, GYRO_CS_Pin, GPIO_PIN_SET);
}

void Gyro_PrintWhoAmI(void) {
	uint8_t commandToSend = (I3G4250D_READ | I3G4250D_WHO_AM_I_ADDR); // Read command to the Who am I register
	uint16_t receivedData = 0x00;

	Gyro_EnableSlaveCommunicationManually();
	while (HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_1) != GPIO_PIN_RESET)
		; // Wait for chip select to go low
	gyroHALStatus = HAL_SPI_TransmitReceive(&hspi5, &commandToSend,
			(uint8_t*) &receivedData, 2, TESTING_TIMEOUT);

	DeviceID = (0xFF00 & receivedData) >> 8; // We only want the last bit. So we discard the last. AGAIN the hal is weird so the first bit recived/sent is the LSB and the last thing sent/recived is the MSB. In this case the first thing recived is 0 because the gyro is reciving the stuff from the stm, then the second byte it sends it.
	//DeviceID = receivedData;
	printf("The Device ID is: %d \n", DeviceID);
	Gyro_DisableSlaveCommunicationManually();
}

void Gyro_PowerOnDevice(void) // This is the version of the function that does not override the other bits in CRTL1 register. We read it first, add a bit, then send it out.
{
	uint16_t crtl1REG = (I3G4250D_READ | I3G4250D_CTRL_REG1_ADDR);
	uint16_t receivedData = 0x00;

	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_TransmitReceive(&hspi5, (uint8_t*) &crtl1REG,
			(uint8_t*) &receivedData, 2, TESTING_TIMEOUT); // Here I read the register, so when we want to change the PD bit it wont affect anything else.
	Gyro_DisableSlaveCommunicationManually();

	//uint16_t powerOnCommand = ((0xFF00 & receivedData) | 0b00001000) | (I3G4250D_WRITE | I3G4250D_CTRL_REG1_ADDR); //The first byte is the defines ( (I3G4250D_READ | I3G4250D_CTRL_REG1_ADDR) ) and the second byte, bits 8-15, have the current reg but with the 1 or'ed in for the PD. The recived data already had the registers value in the second bit, so we dont need to do any bit shifts. Its alread where we want it.
	uint16_t powerOnCommand = ((0xFF00 & receivedData) | 0x08)
			| (I3G4250D_WRITE | I3G4250D_CTRL_REG1_ADDR); //The first byte is the defines ( (I3G4250D_READ | I3G4250D_CTRL_REG1_ADDR) ) and the second byte, bits 8-15, have the current reg but with the 1 or'ed in for the PD. The recived data already had the registers value in the second bit, so we dont need to do any bit shifts. Its alread where we want it.

	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_Transmit(&hspi5, (uint8_t*) &powerOnCommand, 2,
	TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	if (gyroHALStatus != HAL_OK) {
		APPLICATION_ASSERT(false);
	}
}

void Gyro_RebootDevice(void) //This will set bit 7 of register CRTL5 and just reset the "zero refrence" of the gyro.
{
	uint16_t ctrl5Reg = (I3G4250D_READ | I3G4250D_CTRL_REG5_ADDR);
	uint16_t receivedData = 0x00;

	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_TransmitReceive(&hspi5, (uint8_t*) &ctrl5Reg,
			(uint8_t*) &receivedData, 2, TESTING_TIMEOUT); // Here I read the register, so when we want to change the REBOOT bit it wont affect anything else.
	Gyro_DisableSlaveCommunicationManually();

	ctrl5Reg = 0;
	//ctrl5Reg = ((0xFF00 & receivedData) | 0b10000000) | (I3G4250D_WRITE | I3G4250D_CTRL_REG5_ADDR); // The first byte is the command ( (I3G4250D_READ | I3G4250D_CTRL_REG5_ADDR) ) and the second byte, bits 8-15,is the register with the roobot bit ored in.
	ctrl5Reg = ((0xFF00 & receivedData) | 0x80)
			| (I3G4250D_WRITE | I3G4250D_CTRL_REG5_ADDR); // The first byte is the command ( (I3G4250D_READ | I3G4250D_CTRL_REG5_ADDR) ) and the second byte, bits 8-15,is the register with the roobot bit ored in.

	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_Transmit(&hspi5, (uint8_t*) &ctrl5Reg, 2,
	TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	if (gyroHALStatus != HAL_OK) {
		APPLICATION_ASSERT(false);
	}
}

void Gyro_Configure_Regs(void) { //TODO: This will configure all the CTRL reg's. This is needed to get ANY data from the Gyro. ALSO CONFIGS THE FIFO REG
	//TODO: Add without MS bit.
	//uint8_t ctrlReg1 = 0b00011111;					//Data rate - 00; Bandwidth - 01; Normal Mode; Y EN; X EN; Z EN;
	uint8_t ctrlReg1 = 0x1F;
	//uint8_t ctrlReg2 = 0b00000000;					//Nothing //TODO!!! The first two bits are either 1 or 0, loaded from boot. Best to just not change.
	//uint8_t ctrlReg3 = 0b00000000;					//No inturrupts;
	//uint8_t ctrlReg4 = I3G4250D_SCALE_SELECTION;	//I3G4250D_SCALE_SELECTION -> corrispond with the I3G4250D_SENSITIVITY;
	uint8_t ctrlReg4 = 0x10;
	//uint8_t ctrlReg5 = 0b11000000;				//ReBoot Mem; Enable Fifo; -> The reboot bit will reset the zero point, and we need to enable fifo to get data to flow to the output regs.
	uint8_t ctrlReg5 = 0xC0;
	//uint8_t fifoREG = 0b01000000;					// FIFO MUST BE IN STREAM OR BYPASS MODE.
	uint8_t fifoREG = 0x40;

	uint16_t reg = (I3G4250D_WRITE | I3G4250D_CTRL_REG1_ADDR) | ctrlReg1 << 8;
	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_Transmit(&hspi5, (uint8_t*) &reg, 2,
	TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	reg = (I3G4250D_WRITE | I3G4250D_CTRL_REG4_ADDR) | ctrlReg4 << 8;
	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_Transmit(&hspi5, (uint8_t*) &reg, 2,
	TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	reg = (I3G4250D_WRITE | I3G4250D_CTRL_REG5_ADDR) | ctrlReg5 << 8;
	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_Transmit(&hspi5, (uint8_t*) &reg, 2,
	TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	reg = (I3G4250D_WRITE | I3G4250D_FIFO_CTRL_REG_ADDR) | (fifoREG << 8);
	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_Transmit(&hspi5, (uint8_t*) &reg, 2,
	TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	if (gyroHALStatus != HAL_OK) {
		APPLICATION_ASSERT(false);
	}
}

void VerifyGyroHALStatusIsOkay(void) {
	if (gyroHALStatus != HAL_OK) {
		APPLICATION_ASSERT(false);
	}
}

//#define USE_SLAVE_ADDRESS_INCREMENT    0  // This will not be asked in LAB 5

//#if USE_SLAVE_ADDRESS_INCREMENT
//static uint8_t axisReceivedDataArray[8];
//#else
static uint16_t AxisXLow;
static uint16_t AxisXHigh;
static uint16_t AxisYLow;
static uint16_t AxisYHigh;
static uint16_t AxisZLow;
static uint16_t AxisZHigh;
//#endif

static int16_t GyroTemp;
void Gyro_ReadXYZAngRate(void) {
	/*
	 #if USE_SLAVE_ADDRESS_INCREMENT
	 uint64_t readAxisRegistersCommandINCREMENT = (I3G4250D_READ | I3G4250D_MS_BIT | I3G4250D_OUT_X_L_ADDR); //TODO: We need to have dummy data for it to keep reading to send out, keeping the clock signal on. If we just have a uint8, it will grab some stuff at memory not for this. So we make it a uint64.
	 Gyro_EnableSlaveCommunicationManually();
	 gyroHALStatus = HAL_SPI_TransmitReceive(&hspi5, (uint8_t*) &readAxisRegistersCommandINCREMENT, axisReceivedDataArray, 7, TESTING_TIMEOUT); //TODO: All we need to do is send out the command, and keep sending out a clock signal and the GYRO will keep spitting data back because of the MS bit. The bytes is 7, 1 for the register, and the 6 for the High and Low registers of each axis.
	 Gyro_DisableSlaveCommunicationManually();
	 VerifyGyroHALStatusIsOkay();
	 #else
	 */
	uint16_t readAxisRegisterCommand = (I3G4250D_READ | I3G4250D_OUT_X_L_ADDR); // We dont shift it. The HAL sens out LSB first.

	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_TransmitReceive(&hspi5,
			(uint8_t*) &readAxisRegisterCommand, (uint8_t*) &AxisXLow, 2,
			TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	readAxisRegisterCommand = (I3G4250D_READ | I3G4250D_OUT_X_H_ADDR);
	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_TransmitReceive(&hspi5,
			(uint8_t*) &readAxisRegisterCommand, (uint8_t*) &AxisXHigh, 2,
			TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	readAxisRegisterCommand = (I3G4250D_READ | I3G4250D_OUT_Y_L_ADDR);
	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_TransmitReceive(&hspi5,
			(uint8_t*) &readAxisRegisterCommand, (uint8_t*) &AxisYLow, 2,
			TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	readAxisRegisterCommand = (I3G4250D_READ | I3G4250D_OUT_Y_H_ADDR);
	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_TransmitReceive(&hspi5,
			(uint8_t*) &readAxisRegisterCommand, (uint8_t*) &AxisYHigh, 2,
			TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	readAxisRegisterCommand = (I3G4250D_READ | I3G4250D_OUT_Z_L_ADDR);
	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_TransmitReceive(&hspi5,
			(uint8_t*) &readAxisRegisterCommand, (uint8_t*) &AxisZLow, 2,
			TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	readAxisRegisterCommand = (I3G4250D_READ | I3G4250D_OUT_Z_H_ADDR);
	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_TransmitReceive(&hspi5,
			(uint8_t*) &readAxisRegisterCommand, (uint8_t*) &AxisZHigh, 2,
			TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	VerifyGyroHALStatusIsOkay();

	AxisXLow = AxisXLow >> 8; //TODO: The hal fills the LSB with the first byte to send/recive. The first byte recived is just dummy data because thats when the stm is sending the gyro the reg address. So the byte above it has the data we want. So we bitshift.
	AxisXHigh = AxisXHigh >> 8;
	AxisYLow = AxisYLow >> 8;
	AxisYHigh = AxisYHigh >> 8;
	AxisZLow = AxisZLow >> 8;
	AxisZHigh = AxisZHigh >> 8;

//    printf("Axis X, Low Register Raw Value: %d\nAxis X, High Register Raw Value: %d\nAxis Y, Low Register Raw Value: %d\nAxis Y, High Register Raw Value: %d\nAxis Z, Low Register Raw Value: %d\nAxis Z, High Register Raw Value: %d\n", AxisXLow,AxisXHigh,AxisYLow,AxisYHigh,AxisZLow,AxisZHigh);
	//#endif
}

void Gyro_ReadTemperature(void) { // Temp is sampled at 1hz.

	//TSDr - Temperature sensor output change vs. temperature -> -1 °C/digit

	uint16_t readTemperatureRegisterCommand = (I3G4250D_READ
			| I3G4250D_OUT_TEMP_ADDR);
	uint16_t returnedTemperature = 0x00;

	Gyro_EnableSlaveCommunicationManually();
	gyroHALStatus = HAL_SPI_TransmitReceive(&hspi5,
			(uint8_t*) &readTemperatureRegisterCommand,
			(uint8_t*) &returnedTemperature, 2, TESTING_TIMEOUT);
	Gyro_DisableSlaveCommunicationManually();

	GyroTemp = (0xFF00 & returnedTemperature) >> 8; // The LSB contains the first thing to send/ recived, so the temp will be in the second byte, because its the second thing sent to the stm. The first is just dummy data.

	printf("The Temperature (in Celsius) Raw Value: %d\n", (GyroTemp + 6)); //TODO: the +6 is the offset.

	// Conversion Temperature?
}

void Gyro_Process_Gyro_Data(float *dataOut) // Not required by Lab 5
{
	/*
	 #if USE_SLAVE_ADDRESS_INCREMENT
	 int16_t RawData[3];
	 int8_t temp[6] = {axisReceivedDataArray[6], axisReceivedDataArray[5], axisReceivedDataArray[4], axisReceivedDataArray[3], axisReceivedDataArray[2], axisReceivedDataArray[1]};
	 int i = 0;
	 for (i = 0; i < 3; i++)	//TODO: Create a half word from the high and low data sent from the gyro. We want to make sure it is now in a int16 type. The gyro sends it as two parts of a int, with a sign bit at the front.
	 {
	 RawData[i] = (int16_t)(((uint16_t)temp[2 * i] << 8) | temp[2 * i + 1]);		//TODO: NOTE this assumes the gyro is sending data LSbit first. Default is LSB.
	 }
	 for (i = 0; i < 3; i++)	//TODO: Multiply the recived data, and scale it acording to the selected sensitivity.
	 {
	 dataOut[i] = (float)(RawData[i] * I3G4250D_SENSITIVITY);
	 }
	 #else
	 */
	int16_t RawX = (int16_t) ((((uint16_t) AxisXHigh) << 8) | AxisXLow); //We need to form a half word. bitshift high by one byte and combine and cast to signed.
	int16_t RawY = (int16_t) ((((uint16_t) AxisYHigh) << 8) | AxisYLow);
	int16_t RawZ = (int16_t) ((((uint16_t) AxisZHigh) << 8) | AxisZLow);

	dataOut[0] = (float) ((float) RawX * I3G4250D_SENSITIVITY);	//Multiply by the sensitivity. The sensitiviy values are from the scale the gyro operates in. The gyro has 65535 values for the range. But the senstitivity is different for each. So for 500dps a value of 100 will be different than 200dps with a value of 100.
	dataOut[1] = (float) ((float) RawY * I3G4250D_SENSITIVITY);
	dataOut[2] = (float) ((float) RawZ * I3G4250D_SENSITIVITY);
//#endif

}

uint8_t Gyro_Get_Rotation_Rate_Direction() {
	Gyro_ReadXYZAngRate();
	float gyroReadings[3];
	Gyro_Process_Gyro_Data(gyroReadings);
	float gyroData = gyroReadings[GYRO_Z_DATA];
	if (gyroData > 100000) {
		// Fast CCW
		return GYRO_RATE_FAST_CCW;

	} else if (gyroData < 100000 && gyroData > 25000) {
		// Slow CCW
		return GYRO_RATE_SLOW_CCW;

	} else if (gyroData < 25000 && gyroData > -25000) {
		// Neutral
		return GYRO_RATE_NEUTRAL;
	} else if (gyroData < -25000 && gyroData > -100000) {
		// Slow CW
		return GYRO_RATE_SLOW_CW;

	} else if (gyroData < -100000) {
		// Fast CW
		return GYRO_RATE_FAST_CW;
	}
	// Default case shouldn't get hit
	return -1;
}

