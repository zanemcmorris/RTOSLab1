#include "InterruptControl.h"


void EnableInterrupt(uint8_t irqNumber)
{
	if(irqNumber < 32)
	{
		// Configure ISER0
		*NVIC_ISER0 |= (1 << irqNumber);

	}else if((irqNumber >= 32) && (irqNumber < 64))
	{
		uint8_t regOffset = irqNumber % 32;
		// Configure ISER1
		*NVIC_ISER1 |= (1 << regOffset);

	}else if((irqNumber >= 64) && (irqNumber < 96))
	{
		uint8_t regOffset = irqNumber % 64;
		// Configure ISER2
		*NVIC_ISER2 |= (1 << regOffset);

	}	
}

void DisableInterrupt(uint8_t irqNumber)
{
	if(irqNumber < 32)
	{
		// Configure ICER0
		*NVIC_ICER0 |= (1 << irqNumber);

	}else if((irqNumber >= 32) && (irqNumber < 64))
	{
		uint8_t regOffset = irqNumber % 32;
		// Configure ICER1
		*NVIC_ICER1 |= (1 << regOffset);

	}else if((irqNumber >= 64) && (irqNumber < 96))
	{
		uint8_t regOffset = irqNumber % 64;
		// Configure ICER2
		*NVIC_ICER2 |= (1 << regOffset);
	}
}

/* Will be used in next lab, this serves no purpose in lab 3 
void ConfigureInterruptPriority(uint8_t irqNumber, uint8_t irqPriority)
{
	uint8_t registerSelect = irqNumber / 4;
	uint8_t bitFieldSelect = irqNumber % 4;
	uint8_t shiftAmount = (bitFieldSelect * 8) + 4; // Lower half of the register is reserved.
	*(NVIC_IPR0 + registerSelect) |= (irqPriority << shiftAmount);
}
*/

void ClearPendingInterrupt(uint8_t irqNumber)
{
	if(irqNumber < 32)
	{
		// Configure ICER0
		*NVIC_ICPR0 |= (1 << irqNumber);
		
	}else if((irqNumber >= 32) && (irqNumber < 64))
	{
		uint8_t regOffset = irqNumber % 32;
		// Configure ICER1
		*NVIC_ICPR1 |= (1 << regOffset);

	}else if((irqNumber >= 64) && (irqNumber < 96))
	{
		uint8_t regOffset = irqNumber % 64;
		// Configure ICER2
		*NVIC_ICPR2 |= (1 << regOffset);
	}
}

void SetPendingIntterupt(uint8_t irqNumber) // This is techincally not required. TODO - How does this relate to a software interrupt? 
{
	if(irqNumber < 32)
	{
		// Configure ISPR0
		*NVIC_ISPR0 |= (1 << irqNumber);

	}else if((irqNumber >= 32) && (irqNumber < 64))
	{
		uint8_t regOffset = irqNumber % 32;
		// Configure ISPR1
		*NVIC_ISPR1 |= (1 << regOffset);

	}else if((irqNumber >= 64) && (irqNumber < 96))
	{
		uint8_t regOffset = irqNumber % 64;
		// Configure ISPR2
		*NVIC_ISPR2 |= (1 << regOffset);
	}
}

void EXTI_ClearPendingRegister(uint8_t pinNumber)
{
	// Learning Topic - How do we know that this is clearing the right port? 
	if(EXTI->PR & (1 << pinNumber))
	{
		// Clear the bit (register docs say writing 1 clears this)
		EXTI->PR |= (1 << pinNumber);
	}
}