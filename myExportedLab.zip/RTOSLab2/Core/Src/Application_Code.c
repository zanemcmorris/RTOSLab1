/*
 * Application_Code.c
 *
 *  Created on: Jan 12, 2024
 *      Author: Zane
 */

#include "Application_Code.h"
// Global Variables
volatile bool LEDStatus = false;
volatile bool buttonStatus = false;
volatile uint8_t globalGyroDirection = GYRO_RATE_NEUTRAL;
volatile uint32_t counter = 0;

// ----------------------------------
// ------- SETUP FUNCTIONS ----------
// ----------------------------------

void setup_systick() {
	// Setup SYSTICK timer with 100ms period
#if LAB2_USE_INTERUPT
//	if (HAL_SYSTICK_Config(SystemCoreClock / 10))
//		printf("Systick Configured\n");
//	else
//		printf("Systick Not Configured\n");
// Commented this block in favor of using a global counter w/ 1ms period
#endif

	NVIC_EnableIRQ(SysTick_IRQn);
	NVIC_SetPriority(SysTick_IRQn, 0x0);
}

void setupGyro() {
	// HAL_Delays are way too long when systick gets reconfigured
#if LAB2_USE_INTERUPT
	Gyro_Init();
	HAL_Delay(100);
	Gyro_PowerOnDevice();
	HAL_Delay(100);
	Gyro_Configure_Regs();
	HAL_Delay(100);
	Gyro_PrintWhoAmI();
#else
	Gyro_Init();
	HAL_Delay(100);
	Gyro_PowerOnDevice();
	HAL_Delay(100);
	Gyro_Configure_Regs();
	HAL_Delay(100);
	Gyro_PrintWhoAmI();
#endif

}

void setupExti() {
// Setup external interupts for Blue Push Button (USER_BTN)
	GPIO_InitTypeDef GPIO_InitStruct;
	GPIO_InitStruct.Pin = USER_BTN_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING_FALLING;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

	NVIC_EnableIRQ(EXTI0_IRQn);
	NVIC_SetPriority(EXTI0_IRQn, 1); // Lower priority than SysTick
}

void setupApplication() {
	setup_systick();
	setupGyro();
#if LAB2_USE_INTERUPT
	setupExti();
#endif
}

// ----------------------------------
// ------- INTERUPT FUNCTIONS -------
// ----------------------------------

void EXTI0_IRQHandler() {
	printf("Got here!\n");
	NVIC->ICPR[0] |= EXTI0_IRQn;
	ClearPendingInterrupt(EXTI0_IRQn);
	buttonStatus = !buttonStatus;
	if (buttonStatus)
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, 1);
	else
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, 0);
	return;
}

void HAL_SYSTICK_Callback() {
	// Function called from SYSTICK_IRQHandler() on SYSTICK interupt

#if LAB2_USE_INTERUPT
	if (counter++ > 10) {
		counter = 0;
		printf("10 ISR Executed\n");
	}
	globalGyroDirection = Gyro_Get_Rotation_Rate_Direction();
	driveLEDSFromGyro(globalGyroDirection);

#else
	if (counter++ > 1000) {
			counter = 0;
			printf("1k ISR Executed\n");
		}
#endif

}

// ----------------------------------
// ------- HELPER FUNCTIONS ---------
// ----------------------------------
void toggleGreenLED() {
	HAL_GPIO_TogglePin(GREEN_LED_PORT, GREEN_LED_PIN);
}

void toggleRedLED() {
	HAL_GPIO_TogglePin(RED_LED_PORT, RED_LED_PIN);
}

void driveRedLEDFromUserButton() {
	if (HAL_GPIO_ReadPin(USER_BTN_PORT, USER_BTN_PIN)) {
		HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 1);
	} else {
		HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 0);
	}
}

void driveLEDSFromGyro(uint8_t gyroDirection) {
	switch (gyroDirection) {
	case GYRO_RATE_FAST_CCW:
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, 0);
		HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 1);
		break;
	case GYRO_RATE_SLOW_CCW:
		HAL_GPIO_TogglePin(RED_LED_PORT, RED_LED_PIN);
		break;
	case GYRO_RATE_NEUTRAL:
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, 0);
		HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 0);
		break;
	case GYRO_RATE_SLOW_CW:
		HAL_GPIO_TogglePin(GREEN_LED_PORT, GREEN_LED_PIN);
		break;
	case GYRO_RATE_FAST_CW:
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, 1);
		HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 0);
		break;
	default:
		HAL_GPIO_WritePin(GREEN_LED_PORT, GREEN_LED_PIN, 0);
		HAL_GPIO_WritePin(RED_LED_PORT, RED_LED_PIN, 0);
		break;
		return;

	}
}
