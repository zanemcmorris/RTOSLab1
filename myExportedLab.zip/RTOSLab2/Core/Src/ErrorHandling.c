/*
 * ErrorHandling.c
 *
 *  Created on: Apr 22, 2023
 *      Author: Xavion
 */

#include "ErrorHandling.h"
#include <stdio.h>

void APPLICATION_ASSERT(bool condition)
{
    printf("Error Has occurred");
}

